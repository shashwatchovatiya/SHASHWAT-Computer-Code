# multi-card-carousel-using-tailwind-and-javascript
This is a simple project in which i have developed multi item carousel using Javascript and Tailwind CSS.

Note: Images may be subject to copyrights. I have used the images just for development purpose only.